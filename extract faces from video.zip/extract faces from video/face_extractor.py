
import cv2

cam = cv2.VideoCapture(0)

cv2.namedWindow("test")

faceCascade = cv2.CascadeClassifier('haarcascades/haarcascade_frontalface_default.xml')


def extract_images(name):
    img = cv2.imread(name)

    faces = faceCascade.detectMultiScale(img, 1.1, 4)
    i = 1
    for (x, y, w, h) in faces:
        FaceImg = img[y:y + h, x:x + w]
        print(name.split('.')[0])
        # To save an image on disk
        filename = "faces\\"+name.split('/')[1].split('.')[0] + str(i) + '.jpg'
        cv2.imwrite(filename, FaceImg)
        i += 1


img_counter = 0

while True:
    ret, frame = cam.read()
    if not ret:
        print("failed to grab frame")
        break
    cv2.imshow("test", frame)

    k = cv2.waitKey(1)
    if k % 256 == 27:
        # ESC pressed
        print("Escape hit, closing...")
        break
    elif k % 256 == 32:
        # SPACE pressed
        img_name = "images/image_{}.jpg".format(img_counter)
        cv2.imwrite(img_name, frame)
        print("{} written!".format(img_name))
        img_counter += 1
        extract_images(img_name)

cam.release()

cv2.destroyAllWindows()




